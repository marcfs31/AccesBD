package com.marc.app.examenuf1restaurant;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListaReservasFragment extends Fragment {
    private ListaReservasListener mListener;
    RecyclerView recyclerView;
    ListaReservasAdapter listaReservasAdapter;
    List<Reserva> reservaLista = new ArrayList<>();

    public ListaReservasFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_lista_reservas, container, false);

        mListener.listaReservas();

        recyclerView = view.findViewById(R.id.listaReservasRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        listaReservasAdapter = new ListaReservasAdapter();
        recyclerView.setAdapter(listaReservasAdapter);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ListaReservasListener) {
            mListener = (ListaReservasListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement ListaReservasListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface ListaReservasListener {
        void listaReservas();
        void cargarDetalleReserva(Reserva reserva);
    }

    public void cargarReservasRecycler(List<Reserva> reservaListaList) {
        reservaLista = reservaListaList;
        listaReservasAdapter.notifyDataSetChanged();
    }

    public class ListaReservasAdapter extends RecyclerView.Adapter<ListaReservasAdapter.ListaReservasViewHolder> {

        @NonNull
        @Override
        public ListaReservasViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View itemView = getLayoutInflater().inflate(R.layout.reserva_lista_holder, viewGroup, false);
            return new ListaReservasViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull ListaReservasViewHolder listaReservasViewHolder, int i) {
            listaReservasViewHolder.fecha.setText("Fecha: "+ reservaLista.get(i).getFecha());
            listaReservasViewHolder.comensales.setText("Personas: "+reservaLista.get(i).getComensales());
        }

        @Override
        public int getItemCount() {
            return reservaLista.size();
        }

        public class ListaReservasViewHolder extends RecyclerView.ViewHolder {
            TextView fecha, comensales;

            public ListaReservasViewHolder(@NonNull View itemView) {
                super(itemView);
                fecha = itemView.findViewById(R.id.fechaListaTextView);
                comensales = itemView.findViewById(R.id.comensalesListaTextView);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int position = getAdapterPosition();
                        mListener.cargarDetalleReserva(reservaLista.get(position));
                    }
                });
            }
        }
    }
}

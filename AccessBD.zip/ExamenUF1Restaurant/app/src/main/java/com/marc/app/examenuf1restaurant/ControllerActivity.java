package com.marc.app.examenuf1restaurant;

import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// Implementar todos los fragments que va a controllar el Controller (Main)
public class ControllerActivity extends AppCompatActivity implements PlatosFragment.PlatosListener, ReservaFragment.ReservaListener, ListaReservasFragment.ListaReservasListener, DetalleReservaFragment.DetalleReservaListener {
    FirebaseDatabase firebaseDatabase;
    UUID uuid;
    List<Reserva> reservaListaListRecycler = new ArrayList<>();
    Reserva reservaDetalle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controller);

        // Cargar fragment inicial con la imagen
        Fragment fragment = new PantallaInicioFragment();
        cargarFragment(fragment, "INICIO"); // Esto no haría falta
        Log.i("INICIO", "Fragment cargado correctamente");

        // Firebase
        firebaseDatabase = FirebaseDatabase.getInstance();



    }

    // Menus de arriba
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.platosButton:
                // Ir al fragment de los platos
                Fragment fragment = new PlatosFragment();
                cargarFragment(fragment, "JSON");
                return true;
            case R.id.reservaButton:
                Fragment fragment1 = new ReservaFragment();
                cargarFragment(fragment1, "RESERVA");
                return true;
            case R.id.listaReservasButton:
                Fragment fragment2 = new ListaReservasFragment();
                cargarFragment(fragment2, "LISTA");
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void cargarFragment(Fragment fragment, String etiqueta) { // Etiqueta identifica al fragment ya instanciado
        // Poner el fragment en el fragment controller(ControllerActivity)
        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, fragment, etiqueta).addToBackStack(null).commit();
        // El addToBackStacck hace que al darle al boton de atras puedas ir a los fragments que ya se han abierto
    }

    // Metodos de las interficies de los Fragments implementados por el Controller

    // Platos
    public void leerJSON() {
        // Creamos una instancia del Hile y lo ejecutamos pasando la URL de donde sacar el JSON
        MiHilo miHilo = new MiHilo();
        miHilo.execute("https://jdarestaurantapi.firebaseio.com/menu.json");
    }

    // Reserva
    @Override
    public void reserva(Reserva reserva) {
        Reserva reservaFirebase;
        reservaFirebase = reserva;

        // Subir a firebase la reserva con un nombre aleatorio
        uuid = UUID.randomUUID();
        firebaseDatabase.getReference().child("reservas").child(uuid.toString()).setValue(reservaFirebase);

        Toast.makeText(this, "Reserva guardad correctamente", Toast.LENGTH_SHORT).show();
    }

    // Lista reservas
    @Override
    public void listaReservas() {
        reservaListaListRecycler.removeAll(reservaListaListRecycler); // Vaciar la lista para evitar que los valores se repitan al volver a entrar a la opción
        firebaseDatabase.getReference().child("reservas").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Reserva reservaLista;
                reservaLista = dataSnapshot.getValue(Reserva.class);

                reservaListaListRecycler.add(reservaLista); // Añadir elemento sacado de firebases

                ListaReservasFragment fragment = (ListaReservasFragment) getSupportFragmentManager().findFragmentByTag("LISTA");
                fragment.cargarReservasRecycler(reservaListaListRecycler); // Le pasamos los platos sacados de la URL de JSON
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {}

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {}

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {}

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    @Override
    public void cargarDetalleReserva(Reserva reserva) {
        Fragment fragmentDetall = new DetalleReservaFragment();
        cargarFragment(fragmentDetall, "DETALLE");
        reservaDetalle = reserva;
    }

    @Override
    public void pasarDatosReserva() {
        DetalleReservaFragment fragmentDetall = (DetalleReservaFragment) getSupportFragmentManager().findFragmentByTag("DETALLE");

        fragmentDetall.cargarReservaDetalle(reservaDetalle); // Le pasamos la reserva al Fragment para pintarla
    }

    // Hilo para conectarse a internet y bajar los datos del json
    public class MiHilo extends AsyncTask<String,Void,String> {

        // Se ejecuta de fondo y descarga el JSON
        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection connection;
            URL url;
            connection = null;
            String result;
            result ="";

            try{

                url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = connection.getInputStream();

                int data = inputStream.read();

                while(data != -1){
                    result += (char) data;
                    data = inputStream.read();
                }

            }catch (Exception e){

                e.printStackTrace();

            }

            Log.i("RESULT", result);
            return result;
        }

        // Cuando se acaba de ejecutar el hilo
        @Override
        protected void onPostExecute(String data) {
            super.onPostExecute(data);
            Log.i("JSON", data);

            List<Plato> platosRecycler = new ArrayList<>();

            try {
                JSONObject jsonObject = new JSONObject(data);
                // Por cada array [] que tenga el json uno de estos
                JSONArray jsonArrayEntrantes = jsonObject.getJSONArray("entrantes");
                JSONArray jsonArrayPrincipales = jsonObject.getJSONArray("principales");
                JSONArray jsonArrayPostres = jsonObject.getJSONArray("postres");

                Log.i("Entrantes", jsonArrayEntrantes.toString());

                // Iterar sobre los entrantes para ponerlos en la lista de platos
                for(int i=0; i<jsonArrayEntrantes.length(); i++){
                    JSONObject jsonitem = jsonArrayEntrantes.getJSONObject(i);

                    Plato plato = new Plato(jsonitem.getString("ingredientes"),jsonitem.getString("nombre"), jsonitem.getString("precio"));

                    platosRecycler.add(plato);
                }

                Log.i("Principales", jsonArrayEntrantes.toString());
                for(int i=0; i<jsonArrayPrincipales.length(); i++){
                    JSONObject jsonitem = jsonArrayPrincipales.getJSONObject(i);

                    Plato plato = new Plato(jsonitem.getString("ingredientes"),jsonitem.getString("nombre"), jsonitem.getString("precio"));

                    platosRecycler.add(plato);
                }

                Log.i("Postres", jsonArrayEntrantes.toString());
                for(int i=0; i<jsonArrayPostres.length(); i++){
                    JSONObject jsonitem = jsonArrayPostres.getJSONObject(i);

                    Plato plato = new Plato(jsonitem.getString("ingredientes"),jsonitem.getString("nombre"), jsonitem.getString("precio"));

                    platosRecycler.add(plato);
                }

                // Buscamos el fragment instanciado antes con la etiqueta JSON
                PlatosFragment fragment = (PlatosFragment) getSupportFragmentManager().findFragmentByTag("JSON");
                fragment.cargarPlatosRecycler(platosRecycler); // Le pasamos los platos sacados de la URL de JSON

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

package com.marc.app.examenuf1restaurant;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class DetalleReservaFragment extends Fragment {
    private DetalleReservaListener mListener;
    TextView fecha, comensales, nombre, telefono, comentarios;

    public DetalleReservaFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detalle_reserva, container, false);
        fecha = view.findViewById(R.id.fechaDetalleTextView);
        comensales = view.findViewById(R.id.comensalesDetalleTextView);
        nombre = view.findViewById(R.id.nombreDetalleTextView);
        telefono = view.findViewById(R.id.telefonoDetalleTextView);
        comentarios = view.findViewById(R.id.comentariosDetalleTextView);

        mListener.pasarDatosReserva(); // Llamar al metodo que me pasa los datos de la reserva clicada

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof DetalleReservaListener) {
            mListener = (DetalleReservaListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement DetalleReservaListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface DetalleReservaListener {
        void pasarDatosReserva();
    }

    public void cargarReservaDetalle(Reserva reserva) {
        fecha.setText("Fecha: "+ reserva.getFecha());
        comensales.setText("Comnesales: "+ reserva.getComensales());
        nombre.setText("Nombre: "+ reserva.getNombre());
        telefono.setText("Teléfono: "+ reserva.getTelefono());
        comentarios.setText("Comentarios" + reserva.getComentarios());
    }
}

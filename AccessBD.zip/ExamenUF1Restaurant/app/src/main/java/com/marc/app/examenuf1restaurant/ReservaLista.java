package com.marc.app.examenuf1restaurant;

public class ReservaLista {
    String fecha, comensales;

    public ReservaLista() {
    }

    public ReservaLista(String fecha, String comensales) {
        this.fecha = fecha;
        this.comensales = comensales;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getComensales() {
        return comensales;
    }

    public void setComensales(String comensales) {
        this.comensales = comensales;
    }
}

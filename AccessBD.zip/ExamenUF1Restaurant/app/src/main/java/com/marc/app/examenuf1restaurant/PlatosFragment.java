package com.marc.app.examenuf1restaurant;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class PlatosFragment extends Fragment {
    private PlatosListener mListener;
    RecyclerView recyclerView;
    PlatosAdapter platosAdapter;
    List<Plato> platoList = new ArrayList<>();

    public PlatosFragment() {
        // Required empty public constructor
    }

    // Entra solo una vez la primera vez que se instancia el fragment
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    // Cuando se pinta el fragment se llama a este metodo (cuando se refresca etc.)
    // Este onCreateView es el equivalente al onCreate de los activities
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_platos, container, false);

        mListener.leerJSON();


        recyclerView = view.findViewById(R.id.platosRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        platosAdapter = new PlatosAdapter();
        recyclerView.setAdapter(platosAdapter);

        return view;
    }

    // Cuando estoy generando el fragment desde el activity
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof PlatosListener) {
            mListener = (PlatosListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement PlatosListener");
        }
    }

    // Cuando estoy eliminando el fragment desde el activity
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // Cambiamos la interface
    public interface PlatosListener {
        void leerJSON(); // Metodos a implementar por el controller(Main)
    }

    // Pillar los platos de la lista sacada desde el main
    public void cargarPlatosRecycler(List<Plato> platos) {
        platoList = platos;
        platosAdapter.notifyDataSetChanged(); // Notificamos al adapter
    }

    public class PlatosAdapter extends RecyclerView.Adapter<PlatosAdapter.PlatosViewHolder> {

        @NonNull
        @Override
        public PlatosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View itemView = getLayoutInflater().inflate(R.layout.plato_view_holder, viewGroup, false);
            return new PlatosViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull PlatosViewHolder platosViewHolder, int i) {
            platosViewHolder.nombre.setText(platoList.get(i).getNombre());
            platosViewHolder.ingredientes.setText(platoList.get(i).getIngredientes());
            platosViewHolder.precio.setText("Precio: "+platoList.get(i).getPrecio()+" EUR");
        }

        @Override
        public int getItemCount() {
            return platoList.size();
        }

        public class PlatosViewHolder extends RecyclerView.ViewHolder {
            TextView nombre, ingredientes, precio;

            public PlatosViewHolder(@NonNull View itemView) {
                super(itemView);

                nombre = itemView.findViewById(R.id.nombrePlato);
                ingredientes = itemView.findViewById(R.id.ingredientesPlato);
                precio = itemView.findViewById(R.id.precioPlato);
            }
        }
    }
}

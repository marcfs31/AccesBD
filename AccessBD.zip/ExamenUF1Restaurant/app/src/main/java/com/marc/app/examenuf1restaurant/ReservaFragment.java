package com.marc.app.examenuf1restaurant;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ReservaFragment extends Fragment {
    private ReservaListener mListener;
    EditText fechaEditText, comensalesEditText, nombreEditText, telefonoEditText, comentariosEditText;
    Button enviarPeticionBoton;

    public ReservaFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_reserva, container, false);

        fechaEditText = view.findViewById(R.id.fechaEditText);
        comensalesEditText = view.findViewById(R.id.comensalesEditText);
        nombreEditText = view.findViewById(R.id.nombreEditText);
        telefonoEditText = view.findViewById(R.id.telefonoEditText);
        comentariosEditText = view.findViewById(R.id.comentariosEditText);

        enviarPeticionBoton = view.findViewById(R.id.enviarPeticionBtn);

        enviarPeticionBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Reserva reserva = new Reserva();
                reserva.setFecha(fechaEditText.getText().toString());
                reserva.setComensales(comensalesEditText.getText().toString());
                reserva.setNombre(nombreEditText.getText().toString());
                reserva.setTelefono(telefonoEditText.getText().toString());
                reserva.setComentarios(comentariosEditText.getText().toString());
                mListener.reserva(reserva); // Llamar al metodo implementado en el controller
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ReservaListener) {
            mListener = (ReservaListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement ReservaListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface ReservaListener {
        void reserva(Reserva reserva);
    }
}

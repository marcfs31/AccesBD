package com.marc.app.examenuf1restaurant;

public class Plato {
    // Mirar el json de https://jdarestaurantapi.firebaseio.com/menu.json y vemos que los distintos platos tienen este formato
    String ingredientes,nombre,precio;

    public Plato(String ingredientes, String nombre, String precio) {
        this.ingredientes = ingredientes;
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}
